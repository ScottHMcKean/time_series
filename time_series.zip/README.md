# time_series
A repository to showcase time series analysis through Nixtla and Databricks
